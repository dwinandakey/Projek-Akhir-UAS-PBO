/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Dwinanda
 */
public class Akun {

    private static String nomorPengenal;
    private static String nama;
    private static String status;

    /**
     * @return the nomorPengenal
     */
    public static String getNomorPengenal() {
        return nomorPengenal;
    }

    /**
     * @param aNomorPengenal the nomorPengenal to set
     */
    public static void setNomorPengenal(String aNomorPengenal) {
        nomorPengenal = aNomorPengenal;
    }

    /**
     * @return the nama
     */
    public static String getNama() {
        return nama;
    }

    /**
     * @param aNama the nama to set
     */
    public static void setNama(String aNama) {
        nama = aNama;
    }

    /**
     * @return the status
     */
    public static String getStatus() {
        return status;
    }

    /**
     * @param aStatus the status to set
     */
    public static void setStatus(String aStatus) {
        status = aStatus;
    }

    

   

}
